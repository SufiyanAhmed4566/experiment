# Arezzi mockup imagery

- `sofa-ivory.webp`: generated catalogue concept, ivory bouclé modular sofa.
- `sofa-olive.webp`: generated catalogue concept, olive velvet sofa.
- `sofa-rust.webp`: generated catalogue concept, terracotta curved sofa (an additional sample asset).
- `living-room.webp`: generated editorial concept, warm modern interior.
- `chair.jpg`: sample chair photograph from the public Woodex template, https://raw.githubusercontent.com/codewithsadee/woodex/master/assets/images/hero-product-2.jpg (source project: https://github.com/codewithsadee/woodex).

Generated images represent fictional sample furniture, not photographed Arezzi inventory. These assets support the requested experimental mockup.

Generated PNGs were encoded as optimised WebP files for the website. The original PNGs are retained outside the checkout at `/workspace/arezzi-art-originals/`.
