import { useEffect, useRef, useState } from 'react';
import {
  ArrowUpRight,
  ArrowRight,
  Heart,
  Search,
  Menu,
  X,
  MapPin,
  Rotate3D,
  RotateCcw,
  MoveUpRight,
  Leaf,
  Layers3,
  Armchair,
  Ruler,
  Check,
  Plus,
  CalendarDays,
  ChevronDown,
  Sparkles,
} from 'lucide-react';
import SofaScene from './components/SofaScene.jsx';

const fabrics = [
  { name: 'Oat Bouclé', color: '#ded2bd', className: 'oat' },
  { name: 'Olive Linen', color: '#73745a', className: 'olive' },
  { name: 'Terracotta Velvet', color: '#ad7057', className: 'rust' },
  { name: 'Charcoal Weave', color: '#484c46', className: 'charcoal' },
];
const products = [
  {
    id: 'cloud',
    name: 'The Cloud',
    type: 'sofas',
    category: 'MODULAR SOFA',
    subtitle: 'A softer place to land.',
    price: '68,000',
    image: '/images/sofa-ivory.webp',
    tag: 'A HOUSE FAVOURITE',
    colors: ['#d8cbb5', '#777b63', '#bc8c70'],
    size: '240 × 100 × 78 cm',
    material: 'Textured bouclé · solid wood frame',
    description:
      'Generous proportions. Cloud-soft cushions. A beautifully unhurried silhouette. Meet the sofa that makes staying in feel like a very good plan.',
  },
  {
    id: 'forma',
    name: 'The Forma',
    type: 'sofas',
    category: 'EVERYDAY SOFA',
    subtitle: 'Quietly confident. Endlessly comfortable.',
    price: '54,000',
    image: '/images/sofa-olive.webp',
    tag: 'A NEW PERSPECTIVE',
    colors: ['#777b63', '#c6b698', '#5b5b52'],
    size: '218 × 92 × 80 cm',
    material: 'Soft linen blend · solid wood frame',
    description:
      'Clean lines with a wonderfully soft side. The Forma brings thoughtful proportions and everyday comfort into the heart of your living room.',
  },
  {
    id: 'arc',
    name: 'The Arc',
    type: 'chairs',
    category: 'ACCENT CHAIR',
    subtitle: 'Your own little corner of calm.',
    price: '24,000',
    image: '/images/chair.jpg',
    tag: '',
    colors: ['#b78d6b', '#d7c9b5', '#797b6a'],
    size: '82 × 86 × 76 cm',
    material: 'Woven upholstery · sculpted timber',
    description:
      'Sculptural from every angle, comfortable in every moment. A characterful accent for slow mornings, favourite books, and spaces that are entirely yours.',
  },
];
function readSaved(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}
function saveLocal(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* Browsing still works without storage. */
  }
}

function Brand({ light = false }) {
  return (
    <a
      href="#home"
      className={`brand ${light ? 'brand-light' : ''}`}
      aria-label="Arezzi Furniture home"
    >
      <svg className="brand-symbol" viewBox="0 0 50 54" fill="none" aria-hidden="true">
        <path d="M5 46 25 5l21 41h-9L24 18 10 46Z" fill="currentColor" />
        <path
          d="M12 35c0-5 4-8 8-8 5 0 9 6 9 6h8v7H14v6h-3V35Z"
          fill="var(--brand-cutout, #f7f5ef)"
          stroke="currentColor"
          strokeWidth="1.6"
        />
        <path d="M16 33v4h18" stroke="currentColor" strokeWidth="1.4" />
      </svg>
      <span className="brand-type">
        AREZZI<span>F U R N I T U R E</span>
      </span>
    </a>
  );
}

function Modal({ title, children, onClose, wide = false }) {
  const dialog = useRef(null);
  useEffect(() => {
    const previous = document.activeElement;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const element = dialog.current;
    (
      element.querySelector('[data-initial-focus]') ||
      element.querySelector('button, input, select, a[href]')
    )?.focus();
    function handleKey(event) {
      if (event.key === 'Escape') onClose();
      if (event.key === 'Tab') {
        const focusable = [
          ...element.querySelectorAll(
            'button:not([disabled]), input, select, textarea, a[href], [tabindex="0"]',
          ),
        ];
        const first = focusable[0],
          last = focusable[focusable.length - 1];
        if (!element.contains(document.activeElement)) {
          event.preventDefault();
          (event.shiftKey ? last : first)?.focus();
        } else if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first?.focus();
        }
      }
    }
    document.addEventListener('keydown', handleKey);
    return () => {
      document.body.style.overflow = oldOverflow;
      document.removeEventListener('keydown', handleKey);
      previous?.focus();
    };
  }, [onClose]);
  return (
    <div
      className="modal-backdrop"
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        ref={dialog}
        className={`modal ${wide ? 'modal-wide' : ''}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <button className="icon-button modal-close" onClick={onClose} aria-label="Close dialog">
          <X size={22} />
        </button>
        {children}
      </section>
    </div>
  );
}

export default function App() {
  const [fabric, setFabric] = useState(0);
  const [rotating, setRotating] = useState(false);
  const [resetKey, setResetKey] = useState(0);
  const [filter, setFilter] = useState('all');
  const [saved, setSaved] = useState(() => readSaved('arezzi-shortlist', []));
  const [dialog, setDialog] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [search, setSearch] = useState('');
  const [mobileNav, setMobileNav] = useState(false);
  const [visitType, setVisitType] = useState('Showroom visit');
  const [booking, setBooking] = useState(null);
  const [newsletter, setNewsletter] = useState(false);
  const [toast, setToast] = useState('');
  const toastTimer = useRef(null);
  const closeDialog = useRef(() => {
    setDialog(null);
    setSelectedProduct(null);
  }).current;
  useEffect(() => () => clearTimeout(toastTimer.current), []);
  const notify = (message) => {
    setToast(message);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 3200);
  };
  const toggleSaved = (id) => {
    const next = saved.includes(id) ? saved.filter((item) => item !== id) : [...saved, id];
    setSaved(next);
    saveLocal('arezzi-shortlist', next);
    notify(
      next.includes(id)
        ? 'A little inspiration, saved to your shortlist.'
        : 'Removed from your shortlist.',
    );
  };
  const bookVisit = () => {
    setBooking(null);
    setDialog('visit');
    setMobileNav(false);
  };
  const viewProduct = (product) => {
    setSelectedProduct(product);
    setDialog('product');
  };
  const goTo = (id) => {
    document.getElementById(id)?.scrollIntoView({
      behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches
        ? 'instant'
        : 'smooth',
    });
    setMobileNav(false);
  };
  const filtered = products.filter((product) => filter === 'all' || product.type === filter);
  const searchResults = products.filter((product) =>
    `${product.name} ${product.category} ${product.material}`
      .toLowerCase()
      .includes(search.toLowerCase().trim()),
  );
  return (
    <>
      <div className="announcement">
        <span>
          <span className="tiny-star">✳</span> GOOD DESIGN. A LITTLE CLOSER TO HOME.
        </span>
        <button onClick={bookVisit}>
          Discover our Bangalore studio <ArrowUpRight size={13} />
        </button>
      </div>
      <header className="site-header" id="home">
        <Brand />
        <nav className="desktop-nav" aria-label="Main navigation">
          <a href="#collection">
            The collection <ChevronDown size={12} />
          </a>
          <a href="#our-story">Our kind of craft</a>
          <a href="#studio">The Bangalore studio</a>
        </nav>
        <div className="header-actions">
          <button
            className="icon-button"
            aria-label="Search furniture"
            onClick={() => {
              setSearch('');
              setDialog('search');
            }}
          >
            <Search size={19} />
          </button>
          <button
            className="icon-button shortlist-button"
            aria-label={`Open shortlist${saved.length ? `, ${saved.length} saved pieces` : ''}`}
            onClick={() => setDialog('shortlist')}
          >
            <Heart size={19} />
            {saved.length > 0 && <span className="saved-count">{saved.length}</span>}
          </button>
          <span className="nav-divider" />
          <button className="header-visit" onClick={bookVisit}>
            Let’s make it yours <ArrowUpRight size={16} />
          </button>
          <button
            className="icon-button mobile-menu"
            aria-label={mobileNav ? 'Close menu' : 'Open menu'}
            aria-expanded={mobileNav}
            onClick={() => setMobileNav(!mobileNav)}
          >
            {mobileNav ? <X /> : <Menu />}
          </button>
        </div>
        {mobileNav && (
          <nav className="mobile-nav" aria-label="Mobile navigation">
            <button onClick={() => goTo('collection')}>
              The collection <ArrowUpRight />
            </button>
            <button onClick={() => goTo('our-story')}>
              Our kind of craft <ArrowUpRight />
            </button>
            <button onClick={() => goTo('studio')}>
              The Bangalore studio <ArrowUpRight />
            </button>
            <button onClick={bookVisit}>
              Plan your visit <ArrowUpRight />
            </button>
          </nav>
        )}
      </header>

      <main>
        <section className="hero" aria-label="Arezzi Furniture interactive collection">
          <div className="hero-copy">
            <div className="eyebrow">
              <span className="small-line" /> THOUGHTFUL FURNITURE. FEEL-GOOD LIVING.
            </div>
            <h1>
              Spaces that
              <br />
              feel like <em>you.</em>
            </h1>
            <p>
              For slow Sundays. For your favourite people.
              <br className="desktop-break" /> For a life beautifully lived, one seat at a time.
            </p>
            <div className="hero-cta">
              <a className="button button-dark" href="#collection">
                Find your favourite <ArrowUpRight size={18} />
              </a>
              <button
                className="text-link"
                onClick={() => {
                  document.querySelector('.fabric-options button')?.focus();
                  setRotating(true);
                }}
              >
                A little more you <Plus size={15} />
              </button>
            </div>
            <div className="hero-footnote">
              <div className="fabric-stack" aria-hidden="true">
                <span />
                <span />
                <span />
              </div>
              <div>
                <strong>Your space. Your shade. Your story.</strong>
                <span>Made to order, made for you.</span>
              </div>
            </div>
          </div>
          <div className="hero-visual">
            <div className="scene-top">
              <span>
                <span className="status-dot" /> A NEW PERSPECTIVE ON COMFORT
              </span>
              <span className="scene-edition">THE LIVING COLLECTION — 01</span>
            </div>
            <div className="sofa-scene">
              <SofaScene color={fabrics[fabric].color} autoRotate={rotating} resetKey={resetKey} />
            </div>
            <div className="scene-badge">
              <svg viewBox="0 0 80 80" aria-hidden="true">
                <defs>
                  <path id="circleText" d="M40 40m-29 0a29 29 0 1 1 58 0a29 29 0 1 1-58 0" />
                </defs>
                <text>
                  <textPath href="#circleText" textLength="178">
                    DESIGNED FOR LIVING · MADE WITH FEELING ·{' '}
                  </textPath>
                </text>
              </svg>
              <Sparkles size={22} />
            </div>
            <div className="scene-product">
              <span className="eyebrow">MEET YOUR NEW HAPPY PLACE</span>
              <button onClick={() => viewProduct(products[0])}>
                The Cloud Sofa <ArrowUpRight size={21} />
              </button>
              <span>Soft by nature. Yours by design.</span>
            </div>
            <div className="scene-controls">
              <button
                className={rotating ? 'active' : ''}
                aria-label={rotating ? 'Pause sofa rotation' : 'Rotate sofa automatically'}
                aria-pressed={rotating}
                onClick={() => setRotating(!rotating)}
              >
                <Rotate3D size={17} />
                <span>Drag to explore</span>
                <span className="degree">3D</span>
              </button>
              <button
                aria-label="Reset sofa view"
                onClick={() => {
                  setResetKey((key) => key + 1);
                  setRotating(false);
                }}
              >
                <RotateCcw size={15} />
              </button>
            </div>
            <div className="fabric-picker">
              <div>
                <span>A SHADE OF YOU</span>
                <span>{String(fabric + 1).padStart(2, '0')} / 04</span>
              </div>
              <div className="fabric-options">
                {fabrics.map((option, index) => (
                  <button
                    key={option.name}
                    className={`fabric-swatch ${option.className} ${fabric === index ? 'selected' : ''}`}
                    style={{ '--swatch': option.color }}
                    aria-label={`Choose ${option.name}`}
                    aria-pressed={fabric === index}
                    onClick={() => setFabric(index)}
                  >
                    {fabric === index && <Check size={15} />}
                  </button>
                ))}
              </div>
              <p aria-live="polite">
                {fabrics[fabric].name}
                <span>Explore the possibilities</span>
              </p>
            </div>
            <span className="scene-caption">A little imagination. A whole lot of comfort.</span>
          </div>
        </section>

        <section className="values-strip" aria-label="Our approach">
          <div>
            <Armchair />
            <span>Comfort, considered.</span>
          </div>
          <div>
            <Layers3 />
            <span>Crafted to be lived in.</span>
          </div>
          <div>
            <Ruler />
            <span>Made personal.</span>
          </div>
          <div>
            <MapPin />
            <span>At home in Bangalore.</span>
          </div>
        </section>

        <section className="collection section-wrap" id="collection">
          <div className="section-heading">
            <div>
              <div className="eyebrow">THE PIECES YOU’LL COME HOME TO</div>
              <h2>
                Find your kind of <em>comfort.</em>
              </h2>
            </div>
            <a className="underlined-link" href="#products">
              Explore the collection <ArrowUpRight size={17} />
            </a>
          </div>
          <div className="collection-toolbar">
            <div className="filter-tabs" role="group" aria-label="Filter furniture">
              {[
                { id: 'all', label: 'All pieces' },
                { id: 'sofas', label: 'Sofas & sectionals' },
                { id: 'chairs', label: 'Accent chairs' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setFilter(item.id)}
                  aria-pressed={filter === item.id}
                  className={filter === item.id ? 'selected' : ''}
                >
                  {item.label}
                  {filter === item.id && <span>{filtered.length.toString().padStart(2, '0')}</span>}
                </button>
              ))}
            </div>
            <span className="collection-note">Considered details. Uncomplicated living.</span>
          </div>
          <div className="product-grid" id="products">
            {filtered.map((product) => (
              <article className="product-card" key={product.id}>
                <div className="product-image-wrap">
                  <button
                    className="product-image-button"
                    onClick={() => viewProduct(product)}
                    aria-label={`Discover ${product.name}`}
                  >
                    <img
                      src={product.image}
                      alt={`${product.name} in a thoughtfully styled living space`}
                      loading="lazy"
                    />
                    <span className="product-discover">
                      Take a closer look <ArrowUpRight size={17} />
                    </span>
                  </button>
                  {product.tag && <span className="product-tag">{product.tag}</span>}
                  <button
                    className={`product-save ${saved.includes(product.id) ? 'is-saved' : ''}`}
                    aria-label={`${saved.includes(product.id) ? 'Remove' : 'Save'} ${product.name}${saved.includes(product.id) ? ' from shortlist' : ' to shortlist'}`}
                    aria-pressed={saved.includes(product.id)}
                    onClick={() => toggleSaved(product.id)}
                  >
                    <Heart size={17} />
                  </button>
                </div>
                <div className="product-meta">
                  <span>{product.category}</span>
                  <div className="product-colors" aria-label="Available in three colours">
                    {product.colors.map((color) => (
                      <i key={color} style={{ background: color }} />
                    ))}
                  </div>
                </div>
                <div className="product-title-row">
                  <button onClick={() => viewProduct(product)}>{product.name}</button>
                  <span>From ₹{product.price}</span>
                </div>
                <p>{product.subtitle}</p>
              </article>
            ))}
          </div>
          <div className="collection-bottom">
            <span>Something uniquely you in mind?</span>
            <button onClick={bookVisit}>
              Let’s create it together <ArrowUpRight size={16} />
            </button>
          </div>
        </section>

        <section className="story" id="our-story">
          <div className="story-image">
            <img
              src="/images/living-room.webp"
              alt="A warm living room with natural materials, generous seating and soft afternoon light"
              loading="lazy"
            />
            <div className="image-note">
              <span>THE AREZZI WAY</span>
              <p>
                A little intention.
                <br />A lot of heart.
              </p>
              <ArrowUpRight size={25} />
            </div>
          </div>
          <div className="story-copy">
            <div className="eyebrow">BEAUTIFUL IS JUST THE BEGINNING</div>
            <h2>
              Not just furniture.
              <br />
              The feeling of <em>home.</em>
            </h2>
            <p>
              We believe the best spaces don’t just look a certain way. They feel a certain way.
              Relaxed. Welcoming. Unmistakably yours.
            </p>
            <p>
              So we bring together thoughtful design, honest materials and the little details that
              make everyday living feel extraordinary.
            </p>
            <div className="craft-details">
              <div>
                <Leaf size={20} />
                <span>Materials with character</span>
              </div>
              <div>
                <Armchair size={20} />
                <span>Comfort without compromise</span>
              </div>
              <div>
                <Ruler size={20} />
                <span>Your dimensions. Your details.</span>
              </div>
            </div>
            <button className="underlined-link" onClick={bookVisit}>
              Meet your next forever piece <ArrowUpRight size={18} />
            </button>
          </div>
        </section>

        <section className="studio section-wrap" id="studio">
          <div className="studio-heading">
            <div className="eyebrow">
              <MapPin size={13} /> FROM BANGALORE, WITH LOVE
            </div>
            <h2>
              Some things are better
              <br />
              <em>felt in person.</em>
            </h2>
            <p>
              Sink in. Stretch out. Find your favourite corner.
              <br />
              Come over — we’ll put the coffee on.
            </p>
            <button className="button button-dark" onClick={bookVisit}>
              Meet us at the studio <ArrowUpRight size={18} />
            </button>
          </div>
          <div className="studio-card">
            <span className="studio-card-label">YOUR NEXT HAPPY PLACE</span>
            <div className="studio-line-art" aria-hidden="true">
              <span className="arch arch-one" />
              <span className="arch arch-two" />
              <span className="line-sofa" />
              <span className="line-lamp" />
              <span className="line-table" />
            </div>
            <div className="studio-info">
              <span>Indiranagar, Bangalore</span>
              <span>
                A little inspiration awaits. <ArrowUpRight size={17} />
              </span>
            </div>
          </div>
        </section>

        <section className="newsletter">
          <div>
            <span className="eyebrow">A LITTLE AREZZI IN YOUR INBOX</span>
            <h3>Good things. Occasionally.</h3>
          </div>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              const email = new FormData(event.currentTarget).get('email');
              saveLocal('arezzi-newsletter', { email, date: new Date().toISOString() });
              setNewsletter(true);
            }}
          >
            <label className="sr-only" htmlFor="newsletter-email">
              Your email address
            </label>
            <div className="newsletter-input">
              <input
                id="newsletter-email"
                name="email"
                type="email"
                placeholder="Your email address"
                required
                disabled={newsletter}
              />
              <button aria-label="Subscribe to inspiration" disabled={newsletter}>
                {newsletter ? <Check /> : <ArrowRight />}
              </button>
            </div>
            <span aria-live="polite">
              {newsletter
                ? 'You’re on the demo list. A little inspiration, saved.'
                : 'New pieces, fresh perspectives. Just the good stuff.'}
            </span>
          </form>
        </section>
      </main>

      <footer>
        <div className="footer-top">
          <div>
            <Brand light />
            <p>Spaces that feel like you.</p>
          </div>
          <div className="footer-links">
            <a href="#collection">The collection</a>
            <a href="#our-story">Our story</a>
            <button onClick={bookVisit}>
              Come say hello <ArrowUpRight size={13} />
            </button>
          </div>
          <span className="footer-location">
            THOUGHTFULLY DESIGNED.
            <br />
            HAPPILY AT HOME IN BANGALORE.
          </span>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} Arezzi Furniture</span>
          <span>
            A concept worth coming home to.{' '}
            <span className="demo-label">Demo website · Sample products & pricing</span>
          </span>
          <button onClick={() => goTo('home')}>
            Back to top <MoveUpRight size={14} />
          </button>
        </div>
      </footer>

      {toast && (
        <div className="toast" role="status">
          <Check size={17} />
          {toast}
        </div>
      )}

      {dialog === 'search' && (
        <Modal title="Find your favourite furniture" onClose={closeDialog}>
          <div className="eyebrow">A GOOD PLACE TO START</div>
          <h2>
            What feels like <em>you?</em>
          </h2>
          <div className="search-field">
            <Search size={21} />
            <input
              type="search"
              data-initial-focus
              placeholder="Try a sofa, a chair, a little comfort…"
              aria-label="Search collection"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>
          <div className="search-results">
            {searchResults.map((product) => (
              <button key={product.id} onClick={() => viewProduct(product)}>
                <img src={product.image} alt="" />
                <span>
                  <strong>{product.name}</strong>
                  <small>
                    {product.category} · From ₹{product.price}
                  </small>
                </span>
                <ArrowUpRight size={19} />
              </button>
            ))}
            {searchResults.length === 0 && (
              <div className="empty-state">
                <Search size={30} />
                <p>No pieces found just yet.</p>
                <span>Try “sofa”, “chair”, “Cloud” or “Forma”.</span>
                <button className="text-link" onClick={() => setSearch('')}>
                  See all pieces <ArrowRight size={16} />
                </button>
              </div>
            )}
          </div>
        </Modal>
      )}

      {dialog === 'shortlist' && (
        <Modal title="Your furniture shortlist" onClose={closeDialog}>
          <div className="eyebrow">A FEW GOOD POSSIBILITIES</div>
          <h2>
            Your little <em>shortlist.</em>
          </h2>
          {saved.length === 0 ? (
            <div className="empty-state">
              <Heart size={34} />
              <p>Room for a few favourites.</p>
              <span>Tap the heart on any piece to keep it close.</span>
              <button
                className="button button-dark"
                onClick={() => {
                  closeDialog();
                  goTo('collection');
                }}
              >
                Explore the collection <ArrowUpRight size={17} />
              </button>
            </div>
          ) : (
            <>
              <div className="search-results">
                {products
                  .filter((product) => saved.includes(product.id))
                  .map((product) => (
                    <div key={product.id} className="shortlist-row">
                      <button onClick={() => viewProduct(product)}>
                        <img src={product.image} alt="" />
                        <span>
                          <strong>{product.name}</strong>
                          <small>From ₹{product.price}</small>
                        </span>
                      </button>
                      <button
                        className="icon-button"
                        aria-label={`Remove ${product.name} from shortlist`}
                        onClick={() => toggleSaved(product.id)}
                      >
                        <X size={18} />
                      </button>
                    </div>
                  ))}
              </div>
              <button className="button button-dark full-width" onClick={bookVisit}>
                Let’s bring it all together <ArrowUpRight size={17} />
              </button>
            </>
          )}
        </Modal>
      )}

      {dialog === 'product' && selectedProduct && (
        <Modal title={selectedProduct.name} onClose={closeDialog} wide>
          <div className="product-detail">
            <div className="detail-image">
              <img src={selectedProduct.image} alt={`${selectedProduct.name} furniture design`} />
              <span>THOUGHTFULLY MADE. BEAUTIFULLY YOURS.</span>
            </div>
            <div className="detail-copy">
              <div className="eyebrow">{selectedProduct.category}</div>
              <h2>{selectedProduct.name}</h2>
              <span className="detail-price">From ₹{selectedProduct.price}</span>
              <p>{selectedProduct.description}</p>
              <div className="detail-spec">
                <span>
                  <Ruler size={17} />
                  Dimensions
                </span>
                <strong>{selectedProduct.size}</strong>
              </div>
              <div className="detail-spec">
                <span>
                  <Layers3 size={17} />
                  Materials
                </span>
                <strong>{selectedProduct.material}</strong>
              </div>
              <p className="detail-note">
                Made to order. Choose your fabric, finish and perfect proportions with us.
              </p>
              <button className="button button-dark full-width" onClick={bookVisit}>
                Make it yours <ArrowUpRight size={17} />
              </button>
              <button
                className="button button-outline full-width"
                onClick={() => toggleSaved(selectedProduct.id)}
              >
                <Heart
                  size={17}
                  fill={saved.includes(selectedProduct.id) ? 'currentColor' : 'none'}
                />
                {saved.includes(selectedProduct.id)
                  ? 'Saved to your shortlist'
                  : 'Save to your shortlist'}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {dialog === 'visit' && (
        <Modal title="Plan your Arezzi studio visit" onClose={closeDialog}>
          {booking ? (
            <div className="booking-success">
              <div className="success-icon">
                <Check size={28} />
              </div>
              <div className="eyebrow">SOMETHING TO LOOK FORWARD TO</div>
              <h2>
                A little closer to <em>home.</em>
              </h2>
              <p>
                Your demo {booking.type.toLowerCase()} has been saved, {booking.name.split(' ')[0]}.
              </p>
              <div className="booking-summary">
                <CalendarDays size={21} />
                <span>
                  {new Date(booking.date + 'T12:00:00').toLocaleDateString('en-IN', {
                    weekday: 'long',
                    day: 'numeric',
                    month: 'long',
                  })}
                  <small>
                    {booking.time} · {booking.type}
                  </small>
                </span>
              </div>
              <p className="form-disclaimer">
                This is a website mockup. No real appointment has been booked and no message has
                been sent.
              </p>
              <button className="button button-dark" onClick={closeDialog} autoFocus>
                Keep exploring <ArrowUpRight size={17} />
              </button>
            </div>
          ) : (
            <>
              <div className="eyebrow">PULL UP A CHAIR</div>
              <h2>
                Let’s make it <em>personal.</em>
              </h2>
              <p className="modal-intro">
                A new sofa. A fresh start. A few ideas to talk through.
                <br />
                We’d love to help you find your kind of home.
              </p>
              <div className="visit-tabs">
                {['Showroom visit', 'Design consultation'].map((type) => (
                  <button
                    key={type}
                    onClick={() => setVisitType(type)}
                    className={visitType === type ? 'selected' : ''}
                    aria-pressed={visitType === type}
                  >
                    {type}
                  </button>
                ))}
              </div>
              <form
                className="visit-form"
                onSubmit={(event) => {
                  event.preventDefault();
                  const data = Object.fromEntries(new FormData(event.currentTarget));
                  const result = { ...data, type: visitType };
                  saveLocal('arezzi-demo-visit', result);
                  setBooking(result);
                }}
              >
                <label>
                  Your name
                  <input
                    name="name"
                    placeholder="How should we call you?"
                    autoComplete="name"
                    required
                    maxLength={80}
                  />
                </label>
                <label>
                  Email address
                  <input
                    type="email"
                    name="email"
                    placeholder="you@example.com"
                    autoComplete="email"
                    required
                  />
                </label>
                <div className="form-two">
                  <label>
                    A day that works
                    <input
                      type="date"
                      name="date"
                      min={new Date().toLocaleDateString('en-CA')}
                      required
                    />
                  </label>
                  <label>
                    Your preferred time
                    <select name="time" required defaultValue="">
                      <option value="" disabled>
                        Choose a time
                      </option>
                      <option>10:00 AM</option>
                      <option>12:00 PM</option>
                      <option>2:00 PM</option>
                      <option>4:00 PM</option>
                      <option>6:00 PM</option>
                    </select>
                  </label>
                </div>
                <div className="visit-address">
                  <MapPin size={18} />
                  <span>
                    <strong>The Arezzi Studio · Indiranagar</strong>
                    <span>12 Design Avenue, Bangalore 560038 · Sample address</span>
                  </span>
                </div>
                <button className="button button-dark full-width" type="submit">
                  {visitType === 'Showroom visit' ? 'Plan my visit' : 'Let’s talk design'}{' '}
                  <ArrowUpRight size={17} />
                </button>
                <p className="form-disclaimer">
                  Just exploring? So are we. This demo saves your request only in this browser; it
                  doesn’t send a booking.
                </p>
              </form>
            </>
          )}
        </Modal>
      )}
    </>
  );
}
