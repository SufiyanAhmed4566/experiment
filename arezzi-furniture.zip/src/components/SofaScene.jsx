import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

// A real-time, locally generated showroom: no model downloads or API keys required.
export default function SofaScene({
  color = '#ded2bd',
  compact = false,
  autoRotate = false,
  resetKey = 0,
  onReady,
}) {
  const host = useRef(null);
  const sceneState = useRef(null);
  const readyCallback = useRef(onReady);
  const [unavailable, setUnavailable] = useState(false);

  useEffect(() => {
    readyCallback.current = onReady;
  }, [onReady]);

  useEffect(() => {
    const container = host.current;
    if (!container) return;
    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: false,
        powerPreference: 'high-performance',
      });
    } catch {
      setUnavailable(true);
      readyCallback.current?.();
      return;
    }

    let disposed = false;
    let contextLost = false;
    let announcedReady = false;
    let frame = 0;
    let visible = true;
    let rotationDirection = 1;
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.domElement.style.cssText =
      'display:block;width:100%;height:100%;touch-action:pan-y;cursor:grab;outline-offset:-4px;';
    renderer.domElement.tabIndex = 0;
    renderer.domElement.setAttribute(
      'aria-label',
      'Interactive 3D Arezzi sofa. Drag, or use the left and right arrow keys, to change the viewing angle. Press Home to reset the view.',
    );
    renderer.domElement.setAttribute('aria-roledescription', 'interactive 3D viewer');
    renderer.domElement.setAttribute('role', 'application');
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#e7e2d8');
    scene.fog = new THREE.Fog('#e7e2d8', 19, 34);
    const camera = new THREE.PerspectiveCamera(36, 1, 0.1, 70);
    const controls = new OrbitControls(camera, renderer.domElement);
    renderer.domElement.style.touchAction = 'pan-y';
    controls.target.set(0, 0.98, 0);
    controls.enablePan = false;
    controls.enableZoom = false;
    controls.enableDamping = true;
    controls.dampingFactor = 0.075;
    controls.rotateSpeed = 0.45;
    controls.minPolarAngle = Math.PI * 0.29;
    controls.maxPolarAngle = Math.PI * 0.47;
    controls.minAzimuthAngle = -Math.PI * 0.4;
    controls.maxAzimuthAngle = Math.PI * 0.4;
    controls.autoRotateSpeed = 0.65;
    controls.touches.ONE = THREE.TOUCH.ROTATE;

    // Seeded, fine fabric grain creates a restrained woven surface at every angle.
    const fabricCanvas = document.createElement('canvas');
    fabricCanvas.width = fabricCanvas.height = 256;
    const fabricContext = fabricCanvas.getContext('2d');
    const fabricPixels = fabricContext.createImageData(256, 256);
    let seed = 314159;
    const random = () => {
      seed = (seed * 16807) % 2147483647;
      return seed / 2147483647;
    };
    for (let y = 0; y < 256; y++) {
      for (let x = 0; x < 256; x++) {
        const index = (y * 256 + x) * 4;
        const weave = x % 4 < 2 !== y % 4 < 2 ? 12 : -12;
        const value = 135 + weave + random() * 66;
        fabricPixels.data[index] =
          fabricPixels.data[index + 1] =
          fabricPixels.data[index + 2] =
            value;
        fabricPixels.data[index + 3] = 255;
      }
    }
    fabricContext.putImageData(fabricPixels, 0, 0);
    const fabric = new THREE.CanvasTexture(fabricCanvas);
    fabric.wrapS = fabric.wrapT = THREE.RepeatWrapping;
    fabric.repeat.set(2, 2);
    fabric.anisotropy = Math.min(renderer.capabilities.getMaxAnisotropy(), 4);

    const upholstery = new THREE.MeshStandardMaterial({
      color,
      roughness: 1,
      bumpMap: fabric,
      bumpScale: 0.055,
    });
    const pipingMaterial = new THREE.MeshStandardMaterial({
      color: new THREE.Color(color).multiplyScalar(0.91),
      roughness: 1,
    });
    const cream = new THREE.MeshStandardMaterial({
      color: '#e8ddc9',
      roughness: 1,
      bumpMap: fabric,
      bumpScale: 0.034,
    });
    const pillowSand = new THREE.MeshStandardMaterial({
      color: '#a99a7d',
      roughness: 0.98,
      bumpMap: fabric,
      bumpScale: 0.04,
    });
    const wood = new THREE.MeshStandardMaterial({ color: '#30271f', roughness: 0.72 });
    const stone = new THREE.MeshStandardMaterial({ color: '#a79d8a', roughness: 0.89 });
    const plaster = new THREE.MeshStandardMaterial({ color: '#e6e0d5', roughness: 1 });

    const box = (w, h, d, r, material, x, y, z, parent = scene) => {
      const mesh = new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 5, r), material);
      mesh.position.set(x, y, z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      parent.add(mesh);
      return mesh;
    };

    const sofa = new THREE.Group();
    sofa.position.set(-0.18, 0, 0.1);
    scene.add(sofa);
    box(6.45, 0.43, 2.4, 0.18, upholstery, 0, 0.53, 0, sofa);
    box(6.12, 0.12, 2.2, 0.045, wood, 0, 0.285, 0, sofa);
    box(6.2, 1.24, 0.52, 0.2, upholstery, 0, 1.3, -0.98, sofa);

    for (const x of [-2.77, 2.77]) {
      for (const z of [-0.88, 0.88]) {
        const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.06, 0.26, 12), wood);
        foot.position.set(x, 0.14, z);
        foot.castShadow = true;
        sofa.add(foot);
      }
    }

    // Piping follows each seat cushion instead of floating over the upholstery.
    function seatPiping(x, y, z, width, depth) {
      const points = [];
      const radius = 0.2;
      const corners = [
        [width / 2 - radius, depth / 2 - radius, 0],
        [-width / 2 + radius, depth / 2 - radius, Math.PI / 2],
        [-width / 2 + radius, -depth / 2 + radius, Math.PI],
        [width / 2 - radius, -depth / 2 + radius, Math.PI * 1.5],
      ];
      corners.forEach(([cx, cz, angle]) => {
        for (let i = 0; i <= 8; i++) {
          const a = angle + ((i / 8) * Math.PI) / 2;
          points.push(new THREE.Vector3(cx + Math.cos(a) * radius, 0, cz + Math.sin(a) * radius));
        }
      });
      const curve = new THREE.CatmullRomCurve3(points, true, 'centripetal');
      const seam = new THREE.Mesh(
        new THREE.TubeGeometry(curve, 80, 0.009, 4, true),
        pipingMaterial,
      );
      seam.position.set(x, y, z);
      sofa.add(seam);
    }

    for (let i = -1; i <= 1; i++) {
      const x = i * 1.83;
      box(1.81, 0.43, 1.94, 0.2, upholstery, x, 0.95, 0.19, sofa);
      seatPiping(x, 1.105, 0.19, 1.77, 1.9);
      const back = box(1.82, 1.18, 0.52, 0.24, upholstery, x, 1.64, -0.83, sofa);
      back.rotation.x = -0.105;
    }
    for (const x of [-3.03, 3.03]) {
      box(0.64, 1.13, 2.43, 0.27, upholstery, x, 1.04, -0.01, sofa);
    }

    const leftPillow = box(0.88, 0.85, 0.28, 0.13, cream, -2.28, 1.49, -0.44, sofa);
    leftPillow.rotation.set(-0.22, 0.14, -0.2);
    const rightPillow = box(0.82, 0.8, 0.29, 0.14, pillowSand, 2.25, 1.47, -0.44, sofa);
    rightPillow.rotation.set(-0.2, -0.16, 0.16);
    const lumbar = box(1.0, 0.42, 0.27, 0.13, cream, 1.78, 1.31, -0.12, sofa);
    lumbar.rotation.set(-0.14, -0.05, -0.06);

    const floor = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), plaster);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // A soft ambient contact shadow grounds the sofa even on lower-power GPUs.
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = shadowCanvas.height = 128;
    const shadowContext = shadowCanvas.getContext('2d');
    const gradient = shadowContext.createRadialGradient(64, 64, 12, 64, 64, 64);
    gradient.addColorStop(0, 'rgba(43,35,26,.40)');
    gradient.addColorStop(0.5, 'rgba(43,35,26,.23)');
    gradient.addColorStop(1, 'rgba(43,35,26,0)');
    shadowContext.fillStyle = gradient;
    shadowContext.fillRect(0, 0, 128, 128);
    const shadowTexture = new THREE.CanvasTexture(shadowCanvas);
    const contact = new THREE.Mesh(
      new THREE.PlaneGeometry(8.9, 4.3),
      new THREE.MeshBasicMaterial({
        map: shadowTexture,
        transparent: true,
        depthWrite: false,
        opacity: 0.65,
      }),
    );
    contact.rotation.x = -Math.PI / 2;
    contact.position.set(-0.18, 0.014, 0.1);
    scene.add(contact);

    if (!compact) {
      const table = new THREE.Group();
      table.position.set(4.17, 0, -0.5);
      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.45, 0.69, 48), wood);
      base.position.y = 0.345;
      base.castShadow = true;
      const top = new THREE.Mesh(new THREE.CylinderGeometry(0.65, 0.65, 0.1, 64), wood);
      top.position.y = 0.72;
      top.castShadow = true;
      top.receiveShadow = true;
      table.add(base, top);
      const vaseProfile = [
        new THREE.Vector2(0.13, 0),
        new THREE.Vector2(0.2, 0.06),
        new THREE.Vector2(0.23, 0.24),
        new THREE.Vector2(0.16, 0.4),
        new THREE.Vector2(0.08, 0.5),
        new THREE.Vector2(0.08, 0.57),
        new THREE.Vector2(0.065, 0.57),
        new THREE.Vector2(0.065, 0.5),
      ];
      const vase = new THREE.Mesh(new THREE.LatheGeometry(vaseProfile, 32), stone);
      vase.position.set(0.05, 0.77, 0);
      vase.castShadow = true;
      table.add(vase);
      for (let i = 0; i < 3; i++) {
        const stemCurve = new THREE.QuadraticBezierCurve3(
          new THREE.Vector3(0.05, 1.22, 0),
          new THREE.Vector3(-0.05 + i * 0.1, 1.63, 0.03),
          new THREE.Vector3(-0.22 + i * 0.24, 1.98 - i * 0.12, 0.04),
        );
        const stem = new THREE.Mesh(
          new THREE.TubeGeometry(stemCurve, 12, 0.008, 4, false),
          new THREE.MeshStandardMaterial({ color: '#6d654b', roughness: 1 }),
        );
        table.add(stem);
        for (let j = 0; j < 4; j++) {
          const t = 0.45 + j * 0.15;
          const point = stemCurve.getPoint(t);
          const leaf = new THREE.Mesh(
            new THREE.SphereGeometry(0.065, 8, 6),
            new THREE.MeshStandardMaterial({ color: '#777963', roughness: 1 }),
          );
          leaf.scale.set(0.55, 1.5, 1);
          leaf.position.copy(point);
          leaf.position.x += (j % 2 ? 1 : -1) * 0.05;
          leaf.rotation.z = (j % 2 ? -1 : 1) * 0.6;
          table.add(leaf);
        }
      }
      scene.add(table);

      // Architectural panel behind the product gives the studio a sense of scale.
      const wall = box(9.7, 5.7, 0.22, 0.1, plaster, 0.2, 2.85, -4.5);
      wall.castShadow = false;
      const returnWall = box(0.25, 5.8, 5.0, 0.05, plaster, -5.8, 2.9, -2.5);
      returnWall.castShadow = false;
    }

    scene.add(new THREE.HemisphereLight('#fff9ed', '#b4aa98', 1.65));
    const key = new THREE.DirectionalLight('#fff2da', 3.0);
    key.position.set(-4.5, 7, 5);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    key.shadow.camera.left = -8;
    key.shadow.camera.right = 8;
    key.shadow.camera.top = 6;
    key.shadow.camera.bottom = -6;
    key.shadow.normalBias = 0.035;
    key.shadow.bias = -0.0002;
    key.shadow.radius = 5;
    key.target.position.set(0, 0, 0);
    scene.add(key, key.target);
    const fill = new THREE.DirectionalLight('#f5f8ff', 0.65);
    fill.position.set(5, 4, -2);
    scene.add(fill);

    const setCamera = () => {
      const width = container.clientWidth || 700;
      const height = container.clientHeight || 500;
      const aspect = width / height;
      camera.aspect = aspect;
      // Keep the complete silhouette in frame on a narrow mobile viewport.
      const distance = Math.max(
        compact ? 8.0 : 9.0,
        (compact ? 12.3 : 14.5) / Math.max(aspect, 0.65),
      );
      // Flush any pending drag inertia before assigning the canonical view.
      const wasDamping = controls.enableDamping;
      const wasRotating = controls.autoRotate;
      controls.enableDamping = false;
      controls.autoRotate = false;
      controls.update();
      camera.position.set(distance * 0.3, distance * 0.29, distance * 0.88);
      controls.target.set(compact ? 0 : 0.3, 1.0, 0);
      camera.updateProjectionMatrix();
      controls.update();
      controls.enableDamping = wasDamping;
      controls.autoRotate = wasRotating;
      rotationDirection = 1;
      renderer.setSize(width, height, false);
    };
    setCamera();
    const resize = new ResizeObserver(setCamera);
    resize.observe(container);
    const intersection = new IntersectionObserver(
      ([entry]) => {
        visible = entry.isIntersecting;
      },
      { rootMargin: '160px' },
    );
    intersection.observe(container);
    const dragStart = () => {
      renderer.domElement.style.cursor = 'grabbing';
    };
    const dragEnd = () => {
      renderer.domElement.style.cursor = 'grab';
    };
    controls.addEventListener('start', dragStart);
    controls.addEventListener('end', dragEnd);

    const keyboardOrbit = (event) => {
      if (!['ArrowLeft', 'ArrowRight', 'Home'].includes(event.key)) return;
      event.preventDefault();
      if (event.key === 'Home') {
        setCamera();
        return;
      }
      const wasDamping = controls.enableDamping;
      const wasRotating = controls.autoRotate;
      controls.enableDamping = false;
      controls.autoRotate = false;
      controls.update();
      const offset = camera.position.clone().sub(controls.target);
      const spherical = new THREE.Spherical().setFromVector3(offset);
      spherical.theta = THREE.MathUtils.clamp(
        spherical.theta + (event.key === 'ArrowLeft' ? -0.12 : 0.12),
        controls.minAzimuthAngle,
        controls.maxAzimuthAngle,
      );
      camera.position.copy(controls.target).add(offset.setFromSpherical(spherical));
      controls.update();
      controls.enableDamping = wasDamping;
      controls.autoRotate = wasRotating;
    };
    renderer.domElement.addEventListener('keydown', keyboardOrbit);

    const handleContextLoss = (event) => {
      event.preventDefault();
      contextLost = true;
      renderer.domElement.style.visibility = 'hidden';
      renderer.domElement.tabIndex = -1;
      setUnavailable(true);
    };
    const handleContextRestore = () => {
      contextLost = false;
      renderer.domElement.style.visibility = 'visible';
      renderer.domElement.tabIndex = 0;
      setUnavailable(false);
      previous = 0;
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLoss);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestore);

    sceneState.current = { upholstery, pipingMaterial, controls, setCamera, reducedMotion };
    controls.autoRotate = autoRotate && !reducedMotion.matches;
    let previous = 0;
    const animate = (time) => {
      if (disposed) return;
      frame = requestAnimationFrame(animate);
      if (!visible || document.hidden || contextLost) return;
      const delta = previous ? Math.min((time - previous) / 1000, 0.05) : 1 / 60;
      previous = time;
      if (controls.autoRotate) {
        const angle = controls.getAzimuthalAngle();
        let edgeDistance =
          rotationDirection > 0
            ? angle - controls.minAzimuthAngle
            : controls.maxAzimuthAngle - angle;
        if (edgeDistance < 0.025) {
          rotationDirection *= -1;
          edgeDistance = 0;
        }
        // Ease into each side view, then return through the front of the studio.
        controls.autoRotateSpeed =
          rotationDirection * (0.2 + 0.45 * THREE.MathUtils.clamp(edgeDistance / 0.3, 0, 1));
      }
      controls.update(delta);
      renderer.render(scene, camera);
      if (!announcedReady) {
        announcedReady = true;
        readyCallback.current?.();
      }
    };
    frame = requestAnimationFrame(animate);

    return () => {
      disposed = true;
      cancelAnimationFrame(frame);
      resize.disconnect();
      intersection.disconnect();
      renderer.domElement.removeEventListener('keydown', keyboardOrbit);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLoss);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestore);
      controls.dispose();
      const geometries = new Set();
      const materials = new Set();
      scene.traverse((object) => {
        if (object.geometry) geometries.add(object.geometry);
        if (object.material)
          (Array.isArray(object.material) ? object.material : [object.material]).forEach(
            (material) => materials.add(material),
          );
      });
      geometries.forEach((geometry) => geometry.dispose());
      materials.forEach((material) => material.dispose());
      fabric.dispose();
      shadowTexture.dispose();
      renderer.dispose();
      renderer.domElement.remove();
      sceneState.current = null;
    };
    // Geometry and renderer are stable; live product options update below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [compact]);

  useEffect(() => {
    const state = sceneState.current;
    if (!state) return;
    state.upholstery.color.set(color);
    state.pipingMaterial.color.set(color).multiplyScalar(0.91);
  }, [color]);

  useEffect(() => {
    const state = sceneState.current;
    if (state) state.controls.autoRotate = autoRotate && !state.reducedMotion.matches;
  }, [autoRotate]);

  useEffect(() => {
    sceneState.current?.setCamera();
  }, [resetKey]);

  return (
    <div
      ref={host}
      style={{
        width: '100%',
        height: '100%',
        position: 'relative',
        overflow: 'hidden',
        background: '#e7e2d8',
      }}
    >
      {unavailable && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'grid',
            placeItems: 'center',
            background: '#e7e2d8',
          }}
        >
          <img
            src="/images/sofa-ivory.webp"
            alt="Arezzi three-seat sofa in ivory fabric"
            style={{ width: '100%', height: '100%', objectFit: 'contain' }}
          />
          <p
            role="status"
            style={{
              position: 'absolute',
              bottom: 20,
              margin: 0,
              padding: '7px 12px',
              borderRadius: 20,
              background: '#f5f1e9e6',
              color: '#686153',
              font: '12px sans-serif',
            }}
          >
            Ivory photo preview · interactive 3D unavailable
          </p>
        </div>
      )}
    </div>
  );
}
