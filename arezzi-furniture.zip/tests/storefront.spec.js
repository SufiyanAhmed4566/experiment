import { test, expect } from '@playwright/test';

test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Spaces that feel like you.' })).toBeVisible();
});

test('renders the real 3D scene, local photography and responsive page without runtime errors', async ({
  page,
}, testInfo) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.reload();
  const canvas = page.locator('.sofa-scene canvas');
  await expect(canvas).toBeVisible();
  expect(await canvas.evaluate((element) => element.width > 0 && element.height > 0)).toBe(true);
  await expect(page.locator('#products .product-card')).toHaveCount(3);

  // Scroll each lazy image into view and verify decoded image data, not just an <img> tag.
  const images = page.locator('main img');
  await expect(images).toHaveCount(4);
  for (const image of await images.all()) {
    await image.scrollIntoViewIfNeeded();
    await expect
      .poll(() => image.evaluate((element) => element.complete && element.naturalWidth > 0))
      .toBe(true);
  }
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  );
  await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
  await page.screenshot({ path: testInfo.outputPath('storefront.png'), fullPage: true });
  expect(errors).toEqual([]);
});

test('fabric choices change the rendered sofa, with working rotation and reset', async ({
  page,
}) => {
  const canvas = page.locator('.sofa-scene canvas');
  await expect(canvas).toBeVisible();
  const before = await canvas.screenshot();
  await page.getByRole('button', { name: 'Choose Olive Linen' }).click();
  await expect(page.getByRole('button', { name: 'Choose Olive Linen' })).toHaveAttribute(
    'aria-pressed',
    'true',
  );
  await expect(page.getByRole('button', { name: 'Choose Oat Bouclé' })).toHaveAttribute(
    'aria-pressed',
    'false',
  );
  await expect(page.locator('.fabric-picker p')).toContainText('Olive Linen');
  await expect.poll(async () => !(await canvas.screenshot()).equals(before)).toBe(true);

  await page.getByRole('button', { name: 'Rotate sofa automatically' }).click();
  await expect(page.getByRole('button', { name: 'Pause sofa rotation' })).toHaveAttribute(
    'aria-pressed',
    'true',
  );
  await page.getByRole('button', { name: 'Reset sofa view' }).click();
  await expect(page.getByRole('button', { name: 'Rotate sofa automatically' })).toHaveAttribute(
    'aria-pressed',
    'false',
  );
});

test('filters seating and opens the selected product details', async ({ page }) => {
  await page.getByRole('button', { name: 'Accent chairs', exact: true }).click();
  await expect(page.locator('#products .product-card')).toHaveCount(1);
  await expect(page.locator('#products')).toContainText('The Arc');
  await expect(page.locator('#products')).not.toContainText('The Cloud');
  await page.getByRole('button', { name: 'Discover The Arc' }).click();
  const detail = page.getByRole('dialog', { name: 'The Arc', exact: true });
  await expect(detail).toBeVisible();
  await expect(detail).toContainText('82 × 86 × 76 cm');
  await expect(detail).toContainText('From ₹24,000');
  await page.keyboard.press('Escape');
  await expect(detail).not.toBeVisible();
  await page.getByRole('button', { name: 'Sofas & sectionals', exact: true }).click();
  await expect(page.locator('#products .product-card')).toHaveCount(2);
  await expect(page.locator('#products')).not.toContainText('The Arc');
});

test('search finds matching furniture and handles empty results', async ({ page }) => {
  await page.getByRole('button', { name: 'Search furniture' }).click();
  const search = page.getByRole('searchbox', { name: 'Search collection' });
  await expect(search).toBeFocused();
  await search.fill('nothing-like-this');
  await expect(page.getByText('No pieces found just yet.')).toBeVisible();
  await search.fill('Forma');
  const dialog = page.getByRole('dialog', { name: 'Find your favourite furniture' });
  await expect(dialog.locator('.search-results > button')).toHaveCount(1);
  await dialog.getByRole('button', { name: /The Forma/ }).click();
  const detail = page.getByRole('dialog', { name: 'The Forma', exact: true });
  await expect(detail).toBeVisible();
  await expect(detail).toContainText('218 × 92 × 80 cm');
  await detail.getByRole('button', { name: 'Close dialog' }).click();
  await expect(detail).not.toBeVisible();
  await expect(page.getByRole('button', { name: 'Search furniture' })).toBeFocused();
});

test('shortlist survives reload and saved items can be removed', async ({ page }) => {
  await page.getByRole('button', { name: 'Save The Cloud to shortlist' }).click();
  await expect(
    page.getByRole('button', { name: 'Remove The Cloud from shortlist' }),
  ).toHaveAttribute('aria-pressed', 'true');
  await page.reload();
  await page.getByRole('button', { name: 'Open shortlist, 1 saved pieces' }).click();
  const shortlist = page.getByRole('dialog', { name: 'Your furniture shortlist' });
  await expect(shortlist).toContainText('The Cloud');
  await shortlist.getByRole('button', { name: 'Remove The Cloud from shortlist' }).click();
  await expect(shortlist).toContainText('Room for a few favourites.');
  expect(await page.evaluate(() => JSON.parse(localStorage.getItem('arezzi-shortlist')))).toEqual(
    [],
  );
});

test('demo visit validates required fields and saves a clearly local appointment', async ({
  page,
}) => {
  await page.getByRole('button', { name: 'Meet us at the studio' }).click();
  const dialog = page.getByRole('dialog', { name: 'Plan your Arezzi studio visit' });
  await dialog.getByRole('button', { name: 'Plan my visit', exact: true }).click();
  await expect(dialog.getByLabel('Your name')).toBeVisible();
  expect(await page.evaluate(() => localStorage.getItem('arezzi-demo-visit'))).toBeNull();
  expect(await dialog.locator('input:invalid').count()).toBeGreaterThan(0);

  await dialog.getByLabel('Your name').fill('Arezzi Guest');
  await dialog.getByLabel('Email address').fill('guest@example.com');
  const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  await dialog.getByLabel('A day that works').fill(tomorrow);
  await dialog.getByLabel('Your preferred time').selectOption('2:00 PM');
  await dialog.getByRole('button', { name: 'Plan my visit', exact: true }).click();
  await expect(dialog).toContainText('Your demo showroom visit has been saved, Arezzi.');
  await expect(dialog).toContainText(
    'No real appointment has been booked and no message has been sent.',
  );
  // Replacing the form with a confirmation must not strand focus on the page behind the dialog.
  await expect
    .poll(() => dialog.evaluate((element) => element.contains(document.activeElement)))
    .toBe(true);
  for (const key of ['Tab', 'Tab', 'Shift+Tab', 'Shift+Tab']) {
    await page.keyboard.press(key);
    expect(await dialog.evaluate((element) => element.contains(document.activeElement))).toBe(true);
  }
  expect(await page.evaluate(() => JSON.parse(localStorage.getItem('arezzi-demo-visit')))).toEqual({
    name: 'Arezzi Guest',
    email: 'guest@example.com',
    date: tomorrow,
    time: '2:00 PM',
    type: 'Showroom visit',
  });
  await dialog.getByRole('button', { name: 'Keep exploring' }).click();
  await expect(dialog).not.toBeVisible();
});

test('mobile navigation opens and navigates without overflowing the screen', async ({
  page,
}, testInfo) => {
  test.skip(
    testInfo.project.name !== 'mobile',
    'Mobile navigation is intentionally hidden on desktop.',
  );
  const open = page.getByRole('button', { name: 'Open menu' });
  await open.click();
  await expect(page.getByRole('button', { name: 'Close menu' })).toHaveAttribute(
    'aria-expanded',
    'true',
  );
  const navigation = page.getByRole('navigation', { name: 'Mobile navigation' });
  await expect(navigation).toBeVisible();
  await navigation.getByRole('button', { name: 'The collection', exact: true }).click();
  await expect(navigation).not.toBeVisible();
  await expect(page.getByRole('heading', { name: 'Find your kind of comfort.' })).toBeInViewport();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  );
});
