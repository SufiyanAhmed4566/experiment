# Arezzi Furniture

A responsive furniture showroom concept for Bangalore, built with React, Vite, and Three.js. The design takes inspiration from the supplied Arezzi identity: a sculptural monogram, warm metallic accents, and the line “Spaces that feel like you.”

## Run locally

Node.js 24 and npm are recommended. No API keys, database, or external services are needed.

```sh
cd /workspace/experiment
npm ci
npm run dev
```

Vite listens on port 5173. The application serves its images, fonts, and 3D geometry locally, without runtime image, font, or model services.

```sh
npm run build       # Production files in dist/
npm run preview     # Serve the production build on port 4173
npm run format      # Format source files
```

Deploy the contents of `dist/` to a static hosting service. This project does not deploy automatically.

## Included interactions

- A procedural 3D sofa with textured upholstery, drag/keyboard exploration, automatic rotation, and four fabric colours.
- Product category filters, collection search, and product detail dialogs.
- A furniture shortlist saved in the current browser.
- A showroom visit or design consultation form with required-field validation and a local demo confirmation.
- A local newsletter subscription demonstration.
- Responsive navigation, keyboard-accessible dialogs, reduced-motion support, and a fallback for browsers without WebGL.

## Browser checks

```sh
npm run test:e2e
```

The Playwright configuration uses `/usr/bin/chromium` when present. On another machine, install Playwright's Chromium with `npx playwright install chromium`. Tests run against the Vite development server; the configuration starts it when needed. They check desktop and mobile rendering, assets, fabric changes, rotation, filters, search, shortlist persistence, form validation, and navigation.

## Mockup details

Products, prices, product specifications, and the Indiranagar address are illustrative. Bookings and newsletter entries are saved only to browser local storage; nothing is sent to a real business. The site does not take payments. Replace the sample content and integrate an authorised backend before using the forms commercially.

- Product data, fabrics, and showroom details: `src/App.jsx`
- Visual design and responsive layouts: `src/styles.css`
- 3D geometry, camera, materials, and lighting: `src/components/SofaScene.jsx`
- Asset provenance: `public/images/ASSETS.md`

Each cloud task is already isolated. Use the existing `/workspace/experiment` checkout; a separate Git worktree is unnecessary.
